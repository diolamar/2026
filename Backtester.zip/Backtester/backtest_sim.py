import csv
import random
import time
from typing import List, Tuple

PROGRESSION_STEPS = [10, 20, 40, 80, 150, 290, 460, 900, 1400, 2200, 3800, 6000, 10000]
MAX_BET = 10000
STOP_LOSS = -5000
INITIAL_PROFIT = 0

PROB_BLUE = 0.45
PROB_RED = 0.45
PROB_GREEN = 0.10

def choose_bet_side(sequence: List[str]) -> Tuple[str, str]:
    non_tie_results = [v for v in sequence if v in ("Blue", "Red")]
    if not non_tie_results:
        side = random.choice(("PLR", "BNR"))
        return side, f"No history, random {side}"
    latest = non_tie_results[-1]
    latest_side = "PLR" if latest == "Blue" else "BNR"
    if len(non_tie_results) >= 2 and non_tie_results[-1] == non_tie_results[-2]:
        return latest_side, f"Streak {latest}"
    recent = non_tie_results[-4:]
    blue_cnt = sum(1 for v in recent if v == "Blue")
    red_cnt = sum(1 for v in recent if v == "Red")
    if blue_cnt > red_cnt:
        return "PLR", f"Recent favour Blue {blue_cnt}-{red_cnt}"
    if red_cnt > blue_cnt:
        return "BNR", f"Recent favour Red {red_cnt}-{blue_cnt}"
    return latest_side, f"Tie window, follow {latest}"

def run_backtest(rounds: int) -> Tuple[List[dict], dict]:
    results = []
    seq = []
    non_tie_seq = []
    profit = INITIAL_PROFIT
    progression_idx = 0
    win = loss = tie = 0
    resolved_bets = 0
    peak_profit = profit
    max_drawdown = 0
    max_loss_streak = 0
    current_loss_streak = 0
    round_counter = 1
    last_bet_side = None
    last_bet_amount = 0
    last_progression_used = 0
    pending_bet_side = None
    pending_bet_amount = 0
    pending_bet_progression = 0
    pending_bet_note = ""
    pending_round_index = -1

    for round_idx in range(rounds):
        r = random.random()
        if r < PROB_BLUE:
            outcome = "Blue"
        elif r < PROB_BLUE + PROB_RED:
            outcome = "Red"
        else:
            outcome = "Green"
        seq.append(outcome)
        if outcome in ("Blue", "Red"):
            non_tie_seq.append(outcome)

        # Resolve pending bet
        if pending_bet_side is not None and round_idx > pending_round_index:
            expected_color = "Blue" if pending_bet_side == "PLR" else "Red"
            if outcome == "Green":
                event = "tie"
                profit_change = 0
                current_loss_streak = 0
                result_text = "TIE"
                tie += 1
            elif outcome == expected_color:
                event = "win"
                profit_change = pending_bet_amount
                profit += profit_change
                progression_idx = 0
                current_loss_streak = 0
                result_text = "WIN"
                win += 1
            else:
                event = "lose"
                profit_change = -pending_bet_amount
                profit += profit_change
                progression_idx = min(progression_idx + 1, len(PROGRESSION_STEPS)-1)
                current_loss_streak += 1
                max_loss_streak = max(max_loss_streak, current_loss_streak)
                result_text = "LOSE"
                loss += 1
            resolved_bets += 1

            if profit > peak_profit:
                peak_profit = profit
            dd = peak_profit - profit
            if dd > max_drawdown:
                max_drawdown = dd

            results.append({
                "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
                "counter": round_counter,
                "event": event,
                "round_box": f"R{round_idx%6+1}C{round_idx//6+1}",
                "progression_step": pending_bet_progression,
                "bet_side": pending_bet_side,
                "bet_amount": pending_bet_amount,
                "result": outcome,
                "profit_total": profit,
                "resolved_bets": resolved_bets,
                "hit_rate": (win / (win+loss) * 100) if (win+loss) > 0 else 0,
                "note": pending_bet_note,
            })
            round_counter += 1

            pending_bet_side = None
            pending_bet_amount = 0
            pending_bet_progression = 0
            pending_bet_note = ""
            pending_round_index = -1

            if profit <= STOP_LOSS:
                print(f"Stop loss reached at round {round_idx}, profit={profit}")
                break

        # Place new bet if none pending and we have history
        if pending_bet_side is None and len(non_tie_seq) >= 1:
            side, note = choose_bet_side(non_tie_seq)
            step = min(progression_idx, len(PROGRESSION_STEPS)-1)
            amount = PROGRESSION_STEPS[step]
            if amount > MAX_BET:
                print(f"Bet amount {amount} exceeds max bet, stopping.")
                break
            pending_bet_side = side
            pending_bet_amount = amount
            pending_bet_progression = step
            pending_bet_note = note
            pending_round_index = round_idx
            last_bet_side = side
            last_bet_amount = amount
            last_progression_used = step

    total_rounds = len(seq)
    stats = {
        "total_rounds": total_rounds,
        "resolved_bets": resolved_bets,
        "win": win,
        "loss": loss,
        "tie": tie,
        "final_profit": profit,
        "peak_profit": peak_profit,
        "max_drawdown": max_drawdown,
        "max_loss_streak": max_loss_streak,
        "hit_rate": (win/(win+loss)*100) if (win+loss)>0 else 0,
        "total_rounds_simulated": round_idx+1,
    }
    return results, stats

def write_csv(results, filename="results_backtest.csv"):
    with open(filename, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow([
            "timestamp","counter","event","round_box","progression_step",
            "bet_side","bet_amount","result","profit_total","resolved_bets","hit_rate","note"
        ])
        for r in results:
            writer.writerow([
                r["timestamp"], r["counter"], r["event"], r["round_box"],
                r["progression_step"], r["bet_side"], r["bet_amount"],
                r["result"], r["profit_total"], r["resolved_bets"],
                f"{r['hit_rate']:.2f}", r["note"]
            ])
    print(f"CSV written to {filename}")

if __name__ == "__main__":
    random.seed(42)
    print("Starting backtest simulation of 20,000 rounds...")
    results, stats = run_backtest(20000)
    write_csv(results)
    print("\n=== Backtest Statistics ===")
    print(f"Total rounds simulated: {stats['total_rounds_simulated']}")
    print(f"Resolved bets:          {stats['resolved_bets']}")
    print(f"Wins:                   {stats['win']}")
    print(f"Losses:                 {stats['loss']}")
    print(f"Ties:                   {stats['tie']}")
    print(f"Hit rate:               {stats['hit_rate']:.2f}%")
    print(f"Final profit:           {stats['final_profit']}")
    print(f"Peak profit:            {stats['peak_profit']}")
    print(f"Max drawdown:           {stats['max_drawdown']}")
    print(f"Max loss streak:        {stats['max_loss_streak']}")