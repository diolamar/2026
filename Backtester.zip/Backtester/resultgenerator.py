import csv
import random
import sys
from pathlib import Path
from datetime import datetime, timedelta

SCRIPT_DIR = Path(__file__).parent.resolve()
OUTPUT_CSV = SCRIPT_DIR / "results_generated.csv"

PROB_BLUE = 0.45
PROB_RED = 0.45
PROB_GREEN = 0.10
PROGRESSION_STEPS = [10, 20, 40, 80, 150, 290, 460, 900, 1400, 2200, 3800, 6000, 10000]

def generate_synthetic_row(counter, profit, progression_idx, last_non_tie, consecutive_losses):
    r = random.random()
    if r < PROB_BLUE:
        outcome = "Blue"
    elif r < PROB_BLUE + PROB_RED:
        outcome = "Red"
    else:
        outcome = "Green"

    if last_non_tie is None:
        side = random.choice(("PLR", "BNR"))
    else:
        side = "PLR" if last_non_tie == "Blue" else "BNR"

    step = min(progression_idx, len(PROGRESSION_STEPS)-1)
    amount = PROGRESSION_STEPS[step]

    expected = "Blue" if side == "PLR" else "Red"

    if outcome == "Green":
        event = "tie"
        profit_change = 0
        new_progression = progression_idx
        new_consecutive_losses = consecutive_losses  # tie does not reset streak
        result_text = "Green"
    elif outcome == expected:
        event = "win"
        profit_change = amount
        new_progression = 0
        new_consecutive_losses = 0
        result_text = outcome
    else:
        event = "lose"
        profit_change = -amount
        new_consecutive_losses = consecutive_losses + 1
        # progression increases only if loss limit not reached yet (but we check stop later)
        new_progression = min(progression_idx + 1, len(PROGRESSION_STEPS)-1)
        result_text = outcome

    profit += profit_change
    new_last_non_tie = outcome if outcome != "Green" else last_non_tie

    note = ""
    if random.random() < 0.1:
        if event == "win":
            note = random.choice(["streak blue->plr", "tie blue->plr", "blue 3-1->plr"])
        elif event == "lose":
            note = random.choice(["streak red->bnr", "tie red->bnr", "red 1-3->bnr"])
        else:
            note = random.choice(["cd red", "cooldown wait_reset cd=red"])

    box_num = (counter - 1) % (6*18)
    row = (box_num % 6) + 1
    col = (box_num // 6) + 1
    round_box = f"R{row}C{col}"

    timestamp = (datetime.now() + timedelta(seconds=counter * random.randint(20, 40))).strftime("%Y-%m-%d %H:%M:%S")
    hit_rate = 0.0

    return (timestamp, counter, event, round_box, step, side, amount,
            result_text, profit, counter, hit_rate, note), new_progression, new_last_non_tie, profit, new_consecutive_losses

def generate_synthetic(output_csv, num_rows, stop_loss, take_profit, loss_limit):
    rows = []
    profit = 0
    progression_idx = 0
    last_non_tie = None
    consecutive_losses = 0
    stop_reason = None

    for counter in range(1, num_rows + 1):
        (row, new_prog, new_last, new_profit, new_losses) = generate_synthetic_row(
            counter, profit, progression_idx, last_non_tie, consecutive_losses
        )
        rows.append(row)
        progression_idx = new_prog
        last_non_tie = new_last
        profit = new_profit
        consecutive_losses = new_losses

        # Check stop conditions (order: loss streak first, then profit conditions)
        if consecutive_losses >= loss_limit:
            stop_reason = f"max loss streak reached ({consecutive_losses} consecutive losses, limit={loss_limit})"
            break
        if profit <= stop_loss:
            stop_reason = f"stop loss reached (profit={profit} <= {stop_loss})"
            break
        if profit >= take_profit:
            stop_reason = f"take profit reached (profit={profit} >= {take_profit})"
            break

    with open(output_csv, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(["timestamp","counter","event","round_box","progression_step",
                         "bet_side","bet_amount","result","profit_total","resolved_bets","hit_rate","note"])
        writer.writerows(rows)

    print(f"Generated {len(rows)} rows -> {output_csv}")
    if stop_reason:
        print(f"Stopped early because: {stop_reason}")
    else:
        print(f"Completed requested {num_rows} rows without hitting stop conditions.")

if __name__ == "__main__":
    try:
        num = int(input("Number of rounds to simulate (default 20000): ") or "20000")
    except ValueError:
        num = 20000

    try:
        stop_loss = int(input("Stop loss (profit <= this stops, default -5000): ") or "-5000")
    except ValueError:
        stop_loss = -5000

    try:
        take_profit = int(input("Take profit (profit >= this stops, default 2000): ") or "2000")
    except ValueError:
        take_profit = 2000

    try:
        loss_limit = int(input("Max consecutive losses before stopping (default 10): ") or "10")
    except ValueError:
        loss_limit = 10

    print(f"\nSimulating up to {num} rounds with:")
    print(f"  stop_loss = {stop_loss}")
    print(f"  take_profit = {take_profit}")
    print(f"  loss_limit = {loss_limit}")
    generate_synthetic(OUTPUT_CSV, num, stop_loss, take_profit, loss_limit)