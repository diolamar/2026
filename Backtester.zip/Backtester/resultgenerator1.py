import csv
import random
import sys
from pathlib import Path
from datetime import datetime, timedelta

SCRIPT_DIR = Path(__file__).parent.resolve()
OUTPUT_CSV = SCRIPT_DIR / "results_generated.csv"

PROB_BLUE = 0.45
PROB_RED = 0.45
PROB_GREEN = 0.10
PROGRESSION_STEPS = [10, 20, 40, 80, 150, 290, 460, 900, 1400, 2200, 3800, 6000, 10000]

# ---------- Strategy Functions ----------
def fibonacci_step(progression_idx):
    """Fibonacci progression: 1,1,2,3,5,8,13,21... mapped to PROGRESSION_STEPS"""
    fib = [1,1,2,3,5,8,13,21,34,55,89,144,233]
    idx = min(progression_idx, len(fib)-1)
    return fib[idx] * 10   # multiply by 10 to match bet sizes

def dalembert_step(progression_idx, base=10):
    """D'Alembert: increase by 1 unit after loss, decrease by 1 after win, never below base"""
    return base + progression_idx * 10

def choose_side(history, strategy="follow_streak"):
    """history = list of Blue/Red only (non‑tie)"""
    if not history:
        return random.choice(("PLR", "BNR"))
    if strategy == "follow_streak":
        last = history[-1]
        return "PLR" if last == "Blue" else "BNR"
    elif strategy == "opposite_streak":
        last = history[-1]
        return "BNR" if last == "Blue" else "PLR"
    elif strategy == "majority":
        recent = history[-6:]  # look at last 6
        blue = sum(1 for x in recent if x == "Blue")
        red = len(recent) - blue
        if blue > red:
            return "PLR"
        elif red > blue:
            return "BNR"
        else:
            return random.choice(("PLR", "BNR"))
    elif strategy == "alternate":
        return "PLR" if (len(history) % 2 == 0) else "BNR"
    elif strategy == "randomize":
        return random.choice(("PLR", "BNR"))
    elif strategy == "follow_trend":
        # Look at last 5 outcomes (or fewer if not available)
        recent = history[-5:]
        blue = sum(1 for x in recent if x == "Blue")
        red = len(recent) - blue
        if blue > red:
            return "PLR"
        elif red > blue:
            return "BNR"
        else:
            return random.choice(("PLR", "BNR"))
    else:
        # fallback
        return random.choice(("PLR", "BNR"))

def get_bet_amount(progression_idx, progression_type, loss_streak, conservative_mode, cons_multiplier):
    step = min(progression_idx, len(PROGRESSION_STEPS)-1)
    if progression_type == "martingale":
        amount = PROGRESSION_STEPS[step]
    elif progression_type == "fibonacci":
        amount = fibonacci_step(progression_idx)
    else:  # dalembert
        amount = dalembert_step(progression_idx)
    if conservative_mode and loss_streak >= 2:
        amount = int(amount * cons_multiplier)
        if amount < PROGRESSION_STEPS[0]:
            amount = PROGRESSION_STEPS[0]
    return amount

def generate_synthetic_row(counter, profit, progression_idx, last_non_tie, consecutive_losses,
                           loss_limit, progression_type, side_strategy, conservative_multiplier):
    r = random.random()
    if r < PROB_BLUE:
        outcome = "Blue"
    elif r < PROB_BLUE + PROB_RED:
        outcome = "Red"
    else:
        outcome = "Green"

    side = choose_side(last_non_tie, side_strategy)

    step = min(progression_idx, len(PROGRESSION_STEPS)-1)
    amount = get_bet_amount(progression_idx, progression_type, consecutive_losses,
                            conservative_mode=(consecutive_losses >= 2), cons_multiplier=conservative_multiplier)

    expected = "Blue" if side == "PLR" else "Red"

    if outcome == "Green":
        event = "tie"
        profit_change = 0
        new_progression = progression_idx
        new_consecutive_losses = consecutive_losses  # tie does not reset streak
        result_text = "Green"
    elif outcome == expected:
        event = "win"
        profit_change = amount
        new_progression = 0
        new_consecutive_losses = 0
        result_text = outcome
    else:
        event = "lose"
        profit_change = -amount
        new_consecutive_losses = consecutive_losses + 1
        # Check loss limit: reset progression and streak if limit reached
        if new_consecutive_losses >= loss_limit:
            new_progression = 0
            new_consecutive_losses = 0
        else:
            new_progression = min(progression_idx + 1, len(PROGRESSION_STEPS)-1)
        result_text = outcome

    profit += profit_change
    # Update history of non‑tie outcomes
    new_history = last_non_tie[:]
    if outcome != "Green":
        new_history.append(outcome)

    note = ""
    if random.random() < 0.1:
        if event == "win":
            note = random.choice(["streak blue->plr", "tie blue->plr", "blue 3-1->plr"])
        elif event == "lose":
            note = random.choice(["streak red->bnr", "tie red->bnr", "red 1-3->bnr"])
        else:
            note = random.choice(["cd red", "cooldown wait_reset cd=red"])

    box_num = (counter - 1) % (6*18)
    row = (box_num % 6) + 1
    col = (box_num // 6) + 1
    round_box = f"R{row}C{col}"

    timestamp = (datetime.now() + timedelta(seconds=counter * random.randint(20, 40))).strftime("%Y-%m-%d %H:%M:%S")
    hit_rate = 0.0

    return (timestamp, counter, event, round_box, progression_idx, side, amount,
            result_text, profit, counter, hit_rate, note), new_progression, new_history, profit, new_consecutive_losses

def generate_synthetic(output_csv, num_rows, stop_loss, take_profit, loss_limit,
                       progression_type, side_strategy, conservative_multiplier):
    rows = []
    profit = 0
    progression_idx = 0
    history = []          # list of past non‑tie outcomes (Blue/Red)
    consecutive_losses = 0
    stop_reason = None
    loss_resets = 0

    for counter in range(1, num_rows + 1):
        (row, new_prog, new_hist, new_profit, new_losses) = generate_synthetic_row(
            counter, profit, progression_idx, history, consecutive_losses,
            loss_limit, progression_type, side_strategy, conservative_multiplier
        )
        rows.append(row)
        # Detect reset
        if progression_idx > 0 and new_prog == 0 and new_losses == 0 and row[2] == "lose":
            loss_resets += 1
        progression_idx = new_prog
        history = new_hist
        profit = new_profit
        consecutive_losses = new_losses

        # Stop conditions (only profit‑based)
        if profit <= stop_loss:
            stop_reason = f"stop loss reached (profit={profit} <= {stop_loss})"
            break
        if profit >= take_profit:
            stop_reason = f"take profit reached (profit={profit} >= {take_profit})"
            break

    with open(output_csv, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(["timestamp","counter","event","round_box","progression_step",
                         "bet_side","bet_amount","result","profit_total","resolved_bets","hit_rate","note"])
        writer.writerows(rows)

    print(f"Generated {len(rows)} rows -> {output_csv}")
    if stop_reason:
        print(f"Stopped because: {stop_reason}")
    else:
        print(f"Completed {num_rows} rows without hitting stop conditions.")
    print(f"Loss limit resets (progression back to base): {loss_resets}")

if __name__ == "__main__":
    # Basic parameters
    num = int(input("Rounds to simulate (20000): ") or "20000")
    stop_loss = int(input("Stop loss (default -5000): ") or "-5000")
    take_profit = int(input("Take profit (default 2000): ") or "2000")
    loss_limit = int(input("Loss limit (reset after N losses, default 5): ") or "5")

    # Strategy choices
    print("\n--- Strategy Options ---")
    prog_type = input("Progression (martingale/fibonacci/dalembert) [martingale]: ").lower() or "martingale"

    # Side selection via number
    print("\nSide selection strategies:")
    print("1. follow_streak")
    print("2. opposite_streak")
    print("3. majority")
    print("4. alternate")
    print("5. randomize")
    print("6. follow_trend")
    side_choice = input("Enter number (1-6) [default 1]: ") or "1"
    side_map = {
        "1": "follow_streak",
        "2": "opposite_streak",
        "3": "majority",
        "4": "alternate",
        "5": "randomize",
        "6": "follow_trend"
    }
    side_sel = side_map.get(side_choice, "follow_streak")

    cons_mult = float(input("Conservative multiplier after 2 losses (0.5 = half bet, default 0.5): ") or "0.5")

    print(f"\nSimulating with: stop_loss={stop_loss}, take_profit={take_profit}, loss_limit={loss_limit}")
    print(f"Progression={prog_type}, side_strategy={side_sel}, conservative_mult={cons_mult}")

    generate_synthetic(OUTPUT_CSV, num, stop_loss, take_profit, loss_limit,
                       prog_type, side_sel, cons_mult)