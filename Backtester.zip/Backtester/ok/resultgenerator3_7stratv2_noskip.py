import csv
import random
import sys
from pathlib import Path
from datetime import datetime, timedelta

SCRIPT_DIR = Path(__file__).parent.resolve()
OUTPUT_CSV = SCRIPT_DIR / "results_generated.csv"

PROB_BLUE = 0.45
PROB_RED = 0.45
PROB_GREEN = 0.10
PROGRESSION_STEPS = [10, 20, 40, 80, 150, 290, 460, 900, 1400, 2200, 3800, 6000, 10000]

# ---------- Strategy Functions ----------
def fibonacci_step(progression_idx):
    fib = [1,1,2,3,5,8,13,21,34,55,89,144,233]
    idx = min(progression_idx, len(fib)-1)
    return fib[idx] * 10

def dalembert_step(progression_idx, base=10):
    return base + progression_idx * 10

def choose_side(history, strategy="follow_streak"):
    if not history:
        return random.choice(("PLR", "BNR"))

    if strategy == "follow_streak":
        last = history[-1]
        return "PLR" if last == "Blue" else "BNR"
    elif strategy == "opposite_streak":
        last = history[-1]
        return "BNR" if last == "Blue" else "PLR"
    elif strategy == "majority":
        recent = history[-6:]
        blue = sum(1 for x in recent if x == "Blue")
        red = len(recent) - blue
        if blue > red:
            return "PLR"
        elif red > blue:
            return "BNR"
        else:
            return random.choice(("PLR", "BNR"))
    elif strategy == "alternate":
        return "PLR" if (len(history) % 2 == 0) else "BNR"
    elif strategy == "randomize":
        return random.choice(("PLR", "BNR"))
    elif strategy == "follow_trend":
        recent = history[-5:]
        blue = sum(1 for x in recent if x == "Blue")
        red = len(recent) - blue
        if blue > red:
            return "PLR"
        elif red > blue:
            return "BNR"
        else:
            return random.choice(("PLR", "BNR"))
    elif strategy == "pattern_follow":
        # Normal pattern logic (used when anti-streak flag is False)
        if len(history) >= 3:
            last_three = history[-3:]
            if last_three[0] == last_three[2] and last_three[0] != last_three[1]:
                last = history[-1]
                return "BNR" if last == "Blue" else "PLR"
        if len(history) >= 2 and history[-1] == history[-2]:
            last = history[-1]
            return "PLR" if last == "Blue" else "BNR"
        last = history[-1]
        return "PLR" if last == "Blue" else "BNR"
    else:
        return random.choice(("PLR", "BNR"))

def get_bet_amount(progression_idx, progression_type):
    step = min(progression_idx, len(PROGRESSION_STEPS)-1)
    if progression_type == "martingale":
        return PROGRESSION_STEPS[step]
    elif progression_type == "fibonacci":
        return fibonacci_step(progression_idx)
    else:
        return dalembert_step(progression_idx)

def generate_synthetic_row(counter, profit, progression_idx, last_non_tie, consecutive_losses,
                           loss_limit, progression_type, side_strategy, anti_streak_pending):
    r = random.random()
    if r < PROB_BLUE:
        outcome = "Blue"
    elif r < PROB_BLUE + PROB_RED:
        outcome = "Red"
    else:
        outcome = "Green"

    side = ""
    amount = 0
    event = ""
    profit_change = 0
    new_progression = progression_idx
    new_consecutive_losses = consecutive_losses
    result_text = outcome
    note = ""
    new_anti_streak_pending = anti_streak_pending

    # --- Determine bet side ---
    # Anti-streak override for pattern_follow when flag is set
    if side_strategy == "pattern_follow" and anti_streak_pending:
        # Bet opposite of last non-tie result
        if last_non_tie:
            last_color = last_non_tie[-1]
            side = "BNR" if last_color == "Blue" else "PLR"
            note = "anti-streak (after 6 losses)"
        else:
            side = random.choice(("PLR", "BNR"))
            note = "anti-streak fallback (no history)"
        # Clear the flag after using it (regardless of outcome)
        new_anti_streak_pending = False
    else:
        side = choose_side(last_non_tie, side_strategy)

    amount = get_bet_amount(progression_idx, progression_type)
    expected = "Blue" if side == "PLR" else "Red"

    if outcome == "Green":
        event = "tie"
        profit_change = 0
        new_progression = progression_idx
        new_consecutive_losses = consecutive_losses
        result_text = "Green"
    elif outcome == expected:
        event = "win"
        profit_change = amount
        new_progression = 0
        new_consecutive_losses = 0
        result_text = outcome
        # Win resets loss streak, so clear any pending anti-streak flag
        new_anti_streak_pending = False
    else:
        event = "lose"
        profit_change = -amount
        new_consecutive_losses = consecutive_losses + 1
        new_progression = min(progression_idx + 1, len(PROGRESSION_STEPS)-1)
        result_text = outcome
        # After a loss, check if we need to set anti-streak flag for next round
        if side_strategy == "pattern_follow" and new_consecutive_losses >= 6 and not anti_streak_pending:
            new_anti_streak_pending = True
            note += (", will anti-streak next" if note else "will anti-streak next")

    profit += profit_change
    new_history = last_non_tie[:]
    if outcome != "Green":
        new_history.append(outcome)

    # Optional random notes for other events (if no note already)
    if not note and random.random() < 0.1:
        if event == "win":
            note = random.choice(["streak blue->plr", "tie blue->plr", "blue 3-1->plr"])
        elif event == "lose":
            note = random.choice(["streak red->bnr", "tie red->bnr", "red 1-3->bnr"])
        else:
            note = random.choice(["cd red", "cooldown wait_reset cd=red"])

    box_num = (counter - 1) % (6*18)
    row_num = (box_num % 6) + 1
    col = (box_num // 6) + 1
    round_box = f"R{row_num}C{col}"
    timestamp = (datetime.now() + timedelta(seconds=counter * random.randint(20, 40))).strftime("%Y-%m-%d %H:%M:%S")
    hit_rate = 0.0
    resolved_bets = counter

    row = (timestamp, counter, round_box, result_text, side, amount, event, profit, new_progression, resolved_bets, hit_rate, note)
    return row, new_progression, new_history, profit, new_consecutive_losses, note, new_anti_streak_pending

def generate_synthetic(output_csv, num_rows, stop_loss, take_profit, loss_limit,
                       progression_type, side_strategy):
    rows = []
    profit = 0
    progression_idx = 0
    history = []
    consecutive_losses = 0
    stop_reason = None
    anti_streak_pending = False   # new state for pattern_follow anti-streak after 6 losses

    for counter in range(1, num_rows + 1):
        row, new_prog, new_hist, new_profit, new_losses, note, new_anti = generate_synthetic_row(
            counter, profit, progression_idx, history, consecutive_losses,
            loss_limit, progression_type, side_strategy, anti_streak_pending
        )
        triggered = False
        if new_profit <= stop_loss:
            stop_reason = f"stop loss reached (profit={new_profit} <= {stop_loss})"
            triggered = True
            if not note:
                note = f"stop loss at {new_profit}"
            row = list(row)
            row[-1] = note
            row = tuple(row)
        elif new_profit >= take_profit:
            stop_reason = f"take profit reached (profit={new_profit} >= {take_profit})"
            triggered = True
            if not note:
                note = f"take profit at {new_profit}"
            row = list(row)
            row[-1] = note
            row = tuple(row)
        elif new_losses >= loss_limit:
            stop_reason = f"loss limit reached ({new_losses} consecutive losses)"
            triggered = True
            if not note:
                note = f"loss limit reached ({new_losses})"
            row = list(row)
            row[-1] = note
            row = tuple(row)

        rows.append(row)
        progression_idx = new_prog
        history = new_hist
        profit = new_profit
        consecutive_losses = new_losses
        anti_streak_pending = new_anti

        if triggered:
            break

    with open(output_csv, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(["timestamp","counter","round_box","result","bet_side","bet_amount",
                         "event","profit_total","progression_step","resolved_bets","hit_rate","note"])
        writer.writerows(rows)

    print(f"Generated {len(rows)} rows -> {output_csv}")
    if stop_reason:
        print(f"Stopped because: {stop_reason}")
    else:
        print(f"Completed {num_rows} rows without hitting stop conditions.")

if __name__ == "__main__":
    num = int(input("Rounds to simulate (20000): ") or "20000")
    stop_loss = int(input("Stop loss (default -5000): ") or "-5000")
    take_profit = int(input("Take profit (default 2000): ") or "2000")
    loss_limit = int(input("Loss limit (reset after N losses, default 10): ") or "10")

    print("\n--- Strategy Options ---")
    prog_type = input("Progression (martingale/fibonacci/dalembert) [martingale]: ").lower() or "martingale"

    print("\nSide selection strategies:")
    print("1. follow_streak")
    print("2. opposite_streak")
    print("3. majority")
    print("4. alternate")
    print("5. randomize")
    print("6. follow_trend")
    print("7. pattern_follow (after 6 losses, next bet opposite, then normal)")
    side_choice = input("Enter number (1-7) [default 1]: ") or "1"
    side_map = {
        "1": "follow_streak",
        "2": "opposite_streak",
        "3": "majority",
        "4": "alternate",
        "5": "randomize",
        "6": "follow_trend",
        "7": "pattern_follow"
    }
    side_sel = side_map.get(side_choice, "follow_streak")

    print(f"\nSimulating with: stop_loss={stop_loss}, take_profit={take_profit}, loss_limit={loss_limit}")
    print(f"Progression={prog_type}, side_strategy={side_sel}")

    generate_synthetic(OUTPUT_CSV, num, stop_loss, take_profit, loss_limit,
                       prog_type, side_sel)