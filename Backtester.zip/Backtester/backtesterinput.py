import csv
import random
import time
from typing import List, Tuple, Optional

PROGRESSION_STEPS = [10, 20, 40, 80, 150, 290, 460, 900, 1400, 2200, 3800, 6000, 10000]
MAX_BET = 10000
PROB_BLUE = 0.45
PROB_RED = 0.45
PROB_GREEN = 0.10

# Hardcoded conservative mode settings
CONSERVATIVE_BET_MULTIPLIER = 0.5   # half bet after streak
SKIP_AFTER_STREAK = True            # skip one round after hitting threshold
REVERSE_SIDE_ON_STREAK = False      # do not reverse betting side

def choose_bet_side(sequence: List[str]) -> Tuple[str, str]:
    non_tie = [v for v in sequence if v in ("Blue", "Red")]
    if not non_tie:
        side = random.choice(("PLR", "BNR"))
        return side, "random"
    latest = non_tie[-1]
    latest_side = "PLR" if latest == "Blue" else "BNR"
    if len(non_tie) >= 2 and non_tie[-1] == non_tie[-2]:
        return latest_side, f"streak {latest}"
    recent = non_tie[-4:]
    blue = sum(1 for v in recent if v == "Blue")
    red = sum(1 for v in recent if v == "Red")
    if blue > red:
        return "PLR", f"favours blue {blue}-{red}"
    if red > blue:
        return "BNR", f"favours red {red}-{blue}"
    return latest_side, f"tie, follow {latest}"

def run_backtest(rounds: int,
                 loss_limit: int,
                 fixed_stop_loss: int,
                 take_profit: Optional[int],
                 use_trailing: bool,
                 trailing_distance: int,
                 conservative_threshold: int) -> Tuple[List[dict], dict]:

    results = []
    seq = []
    non_tie_seq = []
    profit = 0
    progression_idx = 0
    win = loss = tie = 0
    resolved_bets = 0
    peak_profit = profit
    max_drawdown = 0
    max_loss_streak = 0
    round_counter = 1
    pending_bet_side = None
    pending_bet_amount = 0
    pending_bet_progression = 0
    pending_bet_note = ""
    pending_round_index = -1
    consecutive_losses = 0
    conservative_mode = False
    skip_next_bet = False

    for round_idx in range(rounds):
        r = random.random()
        if r < PROB_BLUE:
            outcome = "Blue"
        elif r < PROB_BLUE + PROB_RED:
            outcome = "Red"
        else:
            outcome = "Green"
        seq.append(outcome)
        if outcome in ("Blue", "Red"):
            non_tie_seq.append(outcome)

        # Resolve pending bet
        if pending_bet_side is not None and round_idx > pending_round_index:
            expected = "Blue" if pending_bet_side == "PLR" else "Red"
            if outcome == "Green":
                event = "tie"
                profit_change = 0
                result_text = "TIE"
                tie += 1
            elif outcome == expected:
                event = "win"
                profit_change = pending_bet_amount
                profit += profit_change
                progression_idx = 0
                consecutive_losses = 0
                conservative_mode = False
                win += 1
                result_text = "WIN"
            else:
                event = "lose"
                profit_change = -pending_bet_amount
                profit += profit_change
                consecutive_losses += 1
                if consecutive_losses > max_loss_streak:
                    max_loss_streak = consecutive_losses
                if not conservative_mode and consecutive_losses >= conservative_threshold:
                    conservative_mode = True
                    if SKIP_AFTER_STREAK:
                        skip_next_bet = True
                if conservative_mode:
                    if consecutive_losses >= loss_limit:
                        progression_idx = 0
                        consecutive_losses = 0
                        conservative_mode = False
                    else:
                        progression_idx = min(progression_idx + 1, len(PROGRESSION_STEPS)-1)
                else:
                    if consecutive_losses >= loss_limit:
                        progression_idx = 0
                        consecutive_losses = 0
                    else:
                        progression_idx = min(progression_idx + 1, len(PROGRESSION_STEPS)-1)
                loss += 1
                result_text = "LOSE"

            resolved_bets += 1
            if profit > peak_profit:
                peak_profit = profit
            dd = peak_profit - profit
            if dd > max_drawdown:
                max_drawdown = dd

            results.append({
                "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
                "counter": round_counter,
                "event": event,
                "round_box": f"R{round_idx%6+1}C{round_idx//6+1}",
                "progression_step": pending_bet_progression,
                "bet_side": pending_bet_side,
                "bet_amount": pending_bet_amount,
                "result": outcome,
                "profit_total": profit,
                "resolved_bets": resolved_bets,
                "hit_rate": (win/(win+loss)*100) if (win+loss)>0 else 0,
                "note": pending_bet_note + (" [CONSERVATIVE]" if conservative_mode else ""),
            })
            round_counter += 1
            pending_bet_side = None

            # Check stop conditions: fixed stop, trailing stop, take profit
            stop_triggered = False
            reason = None
            if take_profit is not None and profit >= take_profit:
                stop_triggered = True
                reason = f"take profit ({take_profit})"
            elif profit <= fixed_stop_loss:
                stop_triggered = True
                reason = f"fixed stop loss ({fixed_stop_loss})"
            elif use_trailing:
                trailing_stop_level = peak_profit - trailing_distance
                if profit <= trailing_stop_level:
                    stop_triggered = True
                    reason = f"trailing stop (peak={peak_profit}, dist={trailing_distance}, level={trailing_stop_level})"
            if stop_triggered:
                print(f"Stop triggered at round {round_idx}, profit={profit}, reason: {reason}")
                break

        # Place new bet
        if pending_bet_side is None and len(non_tie_seq) >= 1:
            if skip_next_bet:
                skip_next_bet = False
                results.append({
                    "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
                    "counter": round_counter,
                    "event": "skip",
                    "round_box": f"R{round_idx%6+1}C{round_idx//6+1}",
                    "progression_step": progression_idx,
                    "bet_side": "",
                    "bet_amount": 0,
                    "result": outcome,
                    "profit_total": profit,
                    "resolved_bets": resolved_bets,
                    "hit_rate": (win/(win+loss)*100) if (win+loss)>0 else 0,
                    "note": "skip after loss streak",
                })
                round_counter += 1
                continue

            side, note = choose_bet_side(non_tie_seq)
            step = min(progression_idx, len(PROGRESSION_STEPS)-1)
            amount = PROGRESSION_STEPS[step]
            if conservative_mode:
                amount = int(amount * CONSERVATIVE_BET_MULTIPLIER)
                if amount < PROGRESSION_STEPS[0]:
                    amount = PROGRESSION_STEPS[0]
                note += f" [conservative bet x{CONSERVATIVE_BET_MULTIPLIER}]"
            if amount > MAX_BET:
                print(f"Max bet exceeded at step {step} amount {amount}")
                break
            pending_bet_side = side
            pending_bet_amount = amount
            pending_bet_progression = step
            pending_bet_note = note
            pending_round_index = round_idx

    stats = {
        "total_rounds_simulated": len(seq),
        "resolved_bets": resolved_bets,
        "win": win, "loss": loss, "tie": tie,
        "final_profit": profit,
        "peak_profit": peak_profit,
        "max_drawdown": max_drawdown,
        "max_loss_streak": max_loss_streak,
        "hit_rate": (win/(win+loss)*100) if (win+loss)>0 else 0,
        "loss_limit_used": loss_limit,
        "fixed_stop_loss_used": fixed_stop_loss,
        "take_profit_used": take_profit if take_profit is not None else 0,
        "trailing_enabled": use_trailing,
        "trailing_distance": trailing_distance if use_trailing else 0,
        "conservative_threshold": conservative_threshold,
        "conservative_bet_multiplier": CONSERVATIVE_BET_MULTIPLIER,
        "skip_after_streak": SKIP_AFTER_STREAK,
        "reverse_side_on_streak": REVERSE_SIDE_ON_STREAK,
    }
    return results, stats

def write_csv(results, filename="results_smart.csv"):
    with open(filename, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(["timestamp","counter","event","round_box","progression_step",
                         "bet_side","bet_amount","result","profit_total","resolved_bets","hit_rate","note"])
        for r in results:
            writer.writerow([r["timestamp"], r["counter"], r["event"], r["round_box"],
                             r["progression_step"], r["bet_side"], r["bet_amount"],
                             r["result"], r["profit_total"], r["resolved_bets"],
                             f"{r['hit_rate']:.2f}", r["note"]])

if __name__ == "__main__":
    print("=== Smart Betting Backtest (Minimises Loss Streaks) ===")
    rounds = int(input("Number of rounds (default 20000): ") or "20000")
    loss_limit = int(input("Loss limit (reset after N losses, default 5): ") or "5")
    fixed_stop = int(input("Fixed stop loss (profit <= this stops, default -5000): ") or "-5000")
    tp_input = input("Take profit (profit >= this stops, leave empty to disable): ").strip()
    take_profit = int(tp_input) if tp_input else None
    use_trail = input("Enable trailing stop? (y/n, default n): ").lower() == 'y'
    trail_dist = 0
    if use_trail:
        trail_dist = int(input("Trailing distance from peak (e.g., 1000): ") or "1000")
    cons_thresh = int(input("Enter conservative mode after this many consecutive losses (default 2): ") or "2")

    results, stats = run_backtest(rounds, loss_limit, fixed_stop, take_profit, use_trail, trail_dist, cons_thresh)
    write_csv(results)
    print("\n=== Statistics ===")
    for k, v in stats.items():
        print(f"{k:35} {v}")